# code LRTF-DFR
***************************************************************************
 Double Factor-Regularized Low-Rank Tensor Factorization for 
        Mixed Noise Removal in Hyperspectral Image
***************************************************************************     
 Copyright:   Yu-Bang Zheng, Ting-Zhu Huang, Xi-Le Zhao, 
                    Yong Chen, and Wei He.                 
***************************************************************************
***************************************************************************
  1). Get Started

  Run generate_noisyHSI.m in the file 'data' if there have no nosiy data
  Run Demo_indian.m 

  
  2). Details
  
  More detail can be found in [1]

  [1] Yu-Bang Zheng, Ting-Zhu Huang*, Xi-Le Zhao*, Yong Chen, and Wei He.
      Double Factor-Regularized Low-Rank Tensor Factorization for 
      Mixed Noise Removal in Hyperspectral Image
***************************************************************************

  3). Please cite our paper if you use any part of our source code.